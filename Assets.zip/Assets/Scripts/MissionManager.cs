using UnityEngine;
using UnityEngine.UI; 

public class MissionManager : MonoBehaviour
{
    public int totalItems = 1;
    private int collectedCount = 0;
    public GameObject winMessage; 

    public void ItemPickedUp()
    {
        collectedCount++;
        Debug.Log("Items: " + collectedCount + "/" + totalItems);

        if (collectedCount >= totalItems)
        {
            CompleteMission();
        }
    }

    void CompleteMission()
    {
        // Show win screen or message
        if (winMessage != null) winMessage.SetActive(true);
    }
}