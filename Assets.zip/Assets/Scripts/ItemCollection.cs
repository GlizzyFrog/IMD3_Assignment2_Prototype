using UnityEngine;

public class CollectibleItem : MonoBehaviour
{
    private bool canCollect = false;

    void Update()
    {
        // 1. Check if the player is in range AND presses F
        if (canCollect && Input.GetKeyDown(KeyCode.F))
        {
            Collect();
        }
    }

    void Collect()
    {
        // 2. Tell the MissionManager to add +1
        FindAnyObjectByType<MissionManager>().ItemPickedUp();

        // 3. Make the item vanish
        gameObject.SetActive(false);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            canCollect = true;
            // Optional: You could show a "Press F to Pick Up" UI here
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            canCollect = false;
        }
    }
}