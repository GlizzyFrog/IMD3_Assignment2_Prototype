using UnityEngine;

public class GlowPulse : MonoBehaviour
{
    public float pulseSpeed = 2.0f;
    private Renderer rend;

    void Start()
    {
        rend = GetComponent<Renderer>();
    }

    void Update()
    {
        float brightness = 1f + Mathf.Sin(Time.time * pulseSpeed) * 0.5f;

        rend.material.SetColor("_EmissionColor", Color.yellow * brightness);
    }
}