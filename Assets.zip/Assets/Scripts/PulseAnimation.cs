using UnityEngine;

public class GlowPulse : MonoBehaviour
{
    public float pulseSpeed = 2.0f;
    private Renderer rend; // This matches your variable name below

    void Start()
    {
        rend = GetComponent<Renderer>();

        // IMPORTANT: This tells Unity the material is allowed to glow
        rend.material.EnableKeyword("_EMISSION");
    }

    void Update()
    {
        // 1. Calculate the pulsing brightness
        float intensity = Mathf.PingPong(Time.time * pulseSpeed, 1.0f) * 10f;

        // 2. Apply the color and intensity
        Color glowColor = Color.yellow * intensity;

        // 3. Use 'rend' instead of 'targetRenderer'
        rend.material.SetColor("_EmissionColor", glowColor);
    }
}