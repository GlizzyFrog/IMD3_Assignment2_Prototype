using UnityEngine;

public class Billboard : MonoBehaviour
{
    private Transform mainCamera;

    void Start()
    {
        mainCamera = Camera.main.transform;
    }

    void LateUpdate()
    {
        // UI always rotate to face the player's camera
        transform.LookAt(transform.position + mainCamera.forward);
    }
}