using UnityEngine;

public class SkyCamera : MonoBehaviour
{
    public Transform target;
    public float distance = 8.0f;
    public float sensitivity = 3.0f;
    public LayerMask collisionLayer;

    private float rotationX = 0f;
    private float rotationY = 0f;

    // Smoothness variables
    private float currentDistance;
    private float velocityDistance = 0f;
    public float smoothTime = 0.2f;

    void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;
        currentDistance = distance;
    }

    void LateUpdate()
    {
        if (target == null) return;

        // Mouse Input
        rotationY += Input.GetAxis("Mouse X") * sensitivity;
        rotationX -= Input.GetAxis("Mouse Y") * sensitivity;
        rotationX = Mathf.Clamp(rotationX, -10, 60);

        // Calculate ideal position
        Quaternion rotation = Quaternion.Euler(rotationX, rotationY, 0);
        Vector3 targetPos = target.position + Vector3.up * 1.5f;
        Vector3 desiredPosition = targetPos - (rotation * Vector3.forward * distance);

        // Collision Check
        float targetDistance = distance;
        RaycastHit hit;
        if (Physics.Linecast(targetPos, desiredPosition, out hit, collisionLayer))
        {
            targetDistance = hit.distance * 0.8f; 
        }

        // Gradually change istandce
        currentDistance = Mathf.SmoothDamp(currentDistance, targetDistance, ref velocityDistance, smoothTime);

        // Position
        Vector3 finalPosition = targetPos - (rotation * Vector3.forward * currentDistance);
        transform.rotation = rotation;
        transform.position = finalPosition;
    }
}