using UnityEngine;

public class SmoothCamera : MonoBehaviour
{
    public Transform target; 
    public float smoothness = 0.125f;
    public Vector3 offset = new Vector3(0, 1, -2);

    void LateUpdate()
    {
        
        Vector3 desiredPosition = target.position + offset;
        transform.position = Vector3.Lerp(transform.position, desiredPosition, smoothness);
        transform.LookAt(target);
    }
}