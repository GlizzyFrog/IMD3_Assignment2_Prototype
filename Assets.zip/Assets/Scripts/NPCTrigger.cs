using UnityEngine;

public class NPCPrompt : MonoBehaviour
{
    public GameObject visualIndicator;

    void Start()
    {
        
        visualIndicator.SetActive(false);
    }

    
    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            visualIndicator.SetActive(true); 
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            visualIndicator.SetActive(false); 
        }
    }
}