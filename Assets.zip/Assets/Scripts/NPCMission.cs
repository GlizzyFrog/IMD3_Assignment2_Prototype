using UnityEngine;
using UnityEngine.UI;

public class NPCTrigger : MonoBehaviour
{
    public GameObject visualIndicator;
    public GameObject missionItems;   
    private bool canTalk = false;
    private bool missionActive = false;

    void Start()
    {
        visualIndicator.SetActive(false);
        missionItems.SetActive(false); 
    }

    void Update()
    {
        
        if (canTalk && Input.GetKeyDown(KeyCode.E) && !missionActive)
        {
            StartCollectionMission();
        }
    }

    void StartCollectionMission()
    {
        missionActive = true;
        missionItems.SetActive(true); 
        visualIndicator.SetActive(false); 
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player") && !missionActive)
        {
            canTalk = true;
            visualIndicator.SetActive(true); 
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            canTalk = false;
            visualIndicator.SetActive(false);
        }
    }
}